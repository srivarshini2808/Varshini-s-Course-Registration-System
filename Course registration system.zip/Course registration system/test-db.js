
require("dotenv").config();
const mysql = require("mysql2/promise");

async function testConnection() {
    console.log("Host:", process.env.DB_HOST);
    console.log("Port:", process.env.DB_PORT || 3306);
    console.log("User:", process.env.DB_USER);
    console.log("Password loaded:", Boolean(process.env.DB_PASSWORD));

    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || "localhost",
            port: Number(process.env.DB_PORT) || 3306,
            user: process.env.DB_USER || "root",
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME || "course_registration"
        });

        const [rows] = await connection.query(
            "SELECT @@hostname AS host, USER() AS login_user, DATABASE() AS db"
        );

        console.log("CONNECTED:", rows[0]);
        await connection.end();
    } catch (error) {
        console.log("ERROR CODE:", error.code);
        console.log("ERROR MESSAGE:", error.message);
    }
}

testConnection();
