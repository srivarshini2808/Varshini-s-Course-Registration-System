
"use strict";

(() => {
    const STORAGE_KEY = "courseRegistrationDemoCourses";
    let selectedDepartment = "";

    const courseForm = document.getElementById("courseForm");
    const courseList = document.getElementById("courseList");
    const courseCount = document.getElementById("courseCount");
    const message = document.getElementById("message");
    const submitText = document.getElementById("submitText");

    if (!courseForm || !courseList || !courseCount) {
        console.error("Course registration elements were not found.");
        return;
    }

    const submitButton = courseForm.querySelector(
        'button[type="submit"]'
    );

    // Demo data is used only when browser storage has no saved courses.
    const demoCourses = [
        {
            course_id: 1,
            course_name: "Python Programming",
            credits: 4,
            department: "CSE",
            semester: 3
        },
        {
            course_id: 2,
            course_name: "Database Management Systems",
            credits: 4,
            department: "CSE",
            semester: 4
        },
        {
            course_id: 3,
            course_name: "Computer Networks",
            credits: 3,
            department: "CSE",
            semester: 5
        },
        {
            course_id: 4,
            course_name: "Digital Electronics",
            credits: 3,
            department: "ECE",
            semester: 3
        },
        {
            course_id: 5,
            course_name: "Engineering Mathematics",
            credits: 4,
            department: "CSE",
            semester: 2
        }
    ];

    function getCourses() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);

            if (saved !== null) {
                const parsed = JSON.parse(saved);
                return Array.isArray(parsed) ? parsed : [...demoCourses];
            }

            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(demoCourses)
            );

            return [...demoCourses];
        } catch (error) {
            console.error("Browser storage error:", error);
            return [...demoCourses];
        }
    }

    let courses = getCourses();

    function saveCourses() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(courses));
            return true;
        } catch (error) {
            console.error("Could not save courses:", error);
            showMessage("Unable to save courses in this browser.", "error");
            return false;
        }
    }

    function showMessage(text, type = "") {
        if (!message) return;
        message.textContent = text;
        message.className = "message" + (type ? " " + type : "");
    }

    function escapeHTML(value) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return String(value ?? "").replace(/[&<>"']/g, character =>
            entities[character]
        );
    }

    function updateOverview() {
        const count = courses.length;
        const credits = courses.reduce(
            (sum, course) => sum + Number(course.credits || 0),
            0
        );

        const dashboardCount = document.getElementById("dashboardCount");
        const plannerCount = document.getElementById("plannerCount");
        const totalCredits = document.getElementById("totalCredits");

        if (dashboardCount) dashboardCount.textContent = count;
        if (plannerCount) plannerCount.textContent = count;
        if (totalCredits) totalCredits.textContent = credits;
    }

    function renderCourses() {
        const visibleCourses = selectedDepartment
            ? courses.filter(course =>
                String(course.department).trim().toUpperCase() ===
                selectedDepartment.trim().toUpperCase()
            )
            : courses;

        courseCount.textContent = String(visibleCourses.length);

        if (visibleCourses.length === 0) {
            courseList.innerHTML = `
                <div class="empty-state">
                    <span class="empty-symbol">✳</span>
                    <h3>No courses found</h3>
                    <p>Add a course or select another department.</p>
                </div>
            `;
            updateOverview();
            return;
        }

        courseList.innerHTML = visibleCourses.map(course => `
            <article class="course-card">
                <div class="course-card-top">
                    <span class="course-tag">Academic course</span>
                    <span class="course-id">
                        #${escapeHTML(course.course_id)}
                    </span>
                </div>

                <h3>${escapeHTML(course.course_name)}</h3>

                <div class="course-meta">
                    <span>${escapeHTML(course.credits)} credits</span>
                    <span>Semester ${escapeHTML(course.semester)}</span>
                </div>

                <div class="course-meta">
                    <span>${escapeHTML(course.department)}</span>
                </div>

                <button
                    class="delete-button"
                    type="button"
                    data-delete-id="${escapeHTML(course.course_id)}">
                    Remove course ×
                </button>
            </article>
        `).join("");

        updateOverview();
    }

    // Register a course in browser storage.
    courseForm.addEventListener("submit", event => {
        event.preventDefault();

        const formData = new FormData(courseForm);

        const courseName = String(
            formData.get("course_name") || ""
        ).trim();

        const department = String(
            formData.get("department") || ""
        ).trim();

        const credits = Number(formData.get("credits"));
        const semester = Number(formData.get("semester"));

        if (
            !courseName ||
            !department ||
            !Number.isInteger(credits) ||
            credits < 1 ||
            credits > 30 ||
            !Number.isInteger(semester) ||
            semester < 1 ||
            semester > 8
        ) {
            showMessage("Please enter valid course details.", "error");
            return;
        }

        const nextId = courses.reduce(
            (max, course) => Math.max(max, Number(course.course_id) || 0),
            0
        ) + 1;

        const newCourse = {
            course_id: nextId,
            course_name: courseName,
            credits,
            department,
            semester
        };

        courses.push(newCourse);

        if (!saveCourses()) {
            courses.pop();
            return;
        }

        selectedDepartment = "";
        courseForm.reset();
        showMessage("Course added successfully!", "success");
        renderCourses();
    });

    // Remove a course from browser storage.
    courseList.addEventListener("click", event => {
        const button = event.target.closest("[data-delete-id]");
        if (!button) return;

        if (!confirm("Are you sure you want to remove this course?")) {
            return;
        }

        const id = button.dataset.deleteId;
        const previousCourses = courses;

        courses = courses.filter(
            course => String(course.course_id) !== String(id)
        );

        if (!saveCourses()) {
            courses = previousCourses;
            return;
        }

        showMessage("Course removed successfully!", "success");
        renderCourses();
    });

    // Navigation shared with the existing HTML.
    const navLinks = document.querySelectorAll(".nav-link");
    const pages = document.querySelectorAll(".page");

    window.showPortalPage = function (
        pageName,
        keepDepartmentFilter = false
    ) {
        const targetPage = document.getElementById(pageName);
        if (!targetPage) return;

        if (pageName !== "courses" || !keepDepartmentFilter) {
            selectedDepartment = "";
        }

        pages.forEach(page => {
            page.classList.toggle("active", page.id === pageName);
        });

        navLinks.forEach(link => {
            link.classList.toggle(
                "active",
                link.dataset.page === pageName
            );
        });

        const pageTitle = document.getElementById("pageTitle");
        const titles = {
            home: "Dashboard",
            register: "Register Course",
            courses: "My Courses",
            departments: "Departments",
            semester: "Semester Planner",
            about: "About Portal"
        };

        if (pageTitle) {
            pageTitle.textContent = titles[pageName] || "Dashboard";
        }

        if (pageName === "courses") renderCourses();
    };

    navLinks.forEach(link => {
        link.addEventListener("click", () => {
            window.showPortalPage(link.dataset.page);
        });
    });

    document.querySelectorAll("[data-go]").forEach(button => {
        button.addEventListener("click", () => {
            window.showPortalPage(button.dataset.go);
        });
    });

    document.querySelectorAll(".department-card").forEach(card => {
        function openDepartmentCourses() {
            selectedDepartment = card.dataset.department || "";
            window.showPortalPage("courses", true);
        }

        card.addEventListener("click", openDepartmentCourses);

        card.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                openDepartmentCourses();
            }
        });
    });

    renderCourses();

    

const demoStudents = [
    { roll: "23CSE001", name: "Aarav Sharma", dept: "CSE", sem: 5, email: "aarav.sharma@gmail.com" },
    { roll: "23CSE002", name: "Ananya Reddy", dept: "CSE", sem: 5, email: "ananya.reddy@gmail.com" },
    { roll: "23CSE003", name: "Rahul Kumar", dept: "CSE", sem: 5, email: "rahul.kumar@gmail.com" },
    { roll: "23CSE004", name: "Priya Patel", dept: "CSE", sem: 5, email: "priya.patel@gmail.com" },
    { roll: "23CSE005", name: "Karthik Rao", dept: "CSE", sem: 5, email: "karthik.rao@gmail.com" },
    { roll: "23CSE006", name: "Sneha Verma", dept: "CSE", sem: 4, email: "sneha.verma@gmail.com" },
    { roll: "23CSE007", name: "Arjun Reddy", dept: "CSE", sem: 4, email: "arjun.reddy@gmail.com" },
    { roll: "23CSE008", name: "Divya Nair", dept: "CSE", sem: 4, email: "divya.nair@gmail.com" },
    { roll: "23CSE009", name: "Vikram Singh", dept: "CSE", sem: 4, email: "vikram.singh@gmail.com" },
    { roll: "23CSE010", name: "Meera Joshi", dept: "CSE", sem: 4, email: "meera.joshi@gmail.com" },
    { roll: "23ECE001", name: "Sai Krishna", dept: "ECE", sem: 5, email: "sai.krishna@gmail.com" },
    { roll: "23ECE002", name: "Pooja Das", dept: "ECE", sem: 5, email: "pooja.das@gmail.com" },
    { roll: "23ECE003", name: "Rohan Gupta", dept: "ECE", sem: 4, email: "rohan.gupta@gmail.com" },
    { roll: "23ECE004", name: "Kavya Rao", dept: "ECE", sem: 4, email: "kavya.rao@gmail.com" },
    { roll: "23ECE005", name: "Aditya Shah", dept: "ECE", sem: 3, email: "aditya.shah@gmail.com" },
    { roll: "23ME001", name: "Manoj Kumar", dept: "Mechanical", sem: 5, email: "manoj.kumar@gmail.com" },
    { roll: "23ME002", name: "Ishita Roy", dept: "Mechanical", sem: 4, email: "ishita.roy@gmail.com" },
    { roll: "23ME003", name: "Varun Reddy", dept: "Mechanical", sem: 3, email: "varun.reddy@gmail.com" },
    { roll: "23ME004", name: "Nisha Jain", dept: "Mechanical", sem: 3, email: "nisha.jain@gmail.com" },
    { roll: "23ME005", name: "Sandeep Rao", dept: "Mechanical", sem: 2, email: "sandeep.rao@gmail.com" },
    { roll: "23MGT001", name: "Neha Kapoor", dept: "Management", sem: 5, email: "neha.kapoor@gmail.com" },
    { roll: "23MGT002", name: "Abhishek Das", dept: "Management", sem: 4, email: "abhishek.das@gmail.com" },
    { roll: "23MGT003", name: "Riya Sharma", dept: "Management", sem: 3, email: "riya.sharma@gmail.com" },
    { roll: "23MGT004", name: "Harish Kumar", dept: "Management", sem: 2, email: "harish.kumar@gmail.com" },
    { roll: "23MGT005", name: "Tanvi Mehta", dept: "Management", sem: 1, email: "tanvi.mehta@gmail.com" }
];


function renderDemoStudents() {
    const tableBody = document.getElementById("studentTableBody");
    if (!tableBody) return;

    tableBody.innerHTML = demoStudents.map(student => `
        <tr>
            <td>${escapeHTML(student.roll)}</td>
            <td>${escapeHTML(student.name)}</td>
            <td>${escapeHTML(student.dept)}</td>
            <td>Semester ${student.sem}</td>
            <td>${escapeHTML(student.email)}</td>
        </tr>
    `).join("");

    const message = document.getElementById("studentMessage");
    if (message) {
       message.textContent = "";
    }
}

renderDemoStudents();

const studentForm = document.getElementById("studentForm");

let savedStudents = JSON.parse(
    localStorage.getItem("courseRegistrationStudents") || "[]"
);

demoStudents.push(...savedStudents);

function saveStudents() {
    localStorage.setItem(
        "courseRegistrationStudents",
        JSON.stringify(demoStudents)
    );
}

function refreshStudentList() {
    renderDemoStudents();

    const total = document.getElementById("totalStudents");
    if (total) total.textContent = demoStudents.length;

    const departments = document.getElementById("totalDepartments");
    if (departments) {
        departments.textContent =
            new Set(demoStudents.map(s => s.dept)).size;
    }

    const semesters = document.getElementById("activeSemesters");
    if (semesters) {
        semesters.textContent =
            new Set(demoStudents.map(s => s.sem)).size;
    }
}

if (studentForm) {
    studentForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const roll = document.getElementById("studentRoll").value.trim();
        const name = document.getElementById("studentName").value.trim();
        const dept = document.getElementById("studentDept").value;
        const sem = Number(document.getElementById("studentSem").value);
        const email = document.getElementById("studentEmail").value.trim();

        const duplicate = demoStudents.some(student =>
            student.roll.toLowerCase() === roll.toLowerCase() ||
            student.email.toLowerCase() === email.toLowerCase()
        );

        if (duplicate) {
            alert("This roll number or email is already registered!");
            return;
        }

        demoStudents.push({ roll, name, dept, sem, email });
        saveStudents();
        refreshStudentList();
        studentForm.reset();

        alert("Student added successfully!");
    });
}

refreshStudentList();

})();
