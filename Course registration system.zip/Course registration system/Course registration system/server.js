require("dotenv").config();

const express = require("express");
const path = require("path");
const pool = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Check server and database
app.get("/api/health", async (req, res) => {
    try {
        await pool.query("SELECT 1");
        res.json({
            success: true,
            message: "Server and database connected"
        });
    } catch (error) {
        console.error("Database connection error:", error.message);
        res.status(500).json({
            success: false,
            message: "Database connection failed"
        });
    }
});

app.get("/api/db-check", async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT
                DATABASE() AS database_name,
                COUNT(*) AS total_courses
            FROM courses
        `);
        res.json(rows[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get all courses
app.get("/api/courses", async (req, res) => {
    try {
        const [courses] = await pool.query(
            `SELECT course_id, course_name, credits,
                    department, semester
             FROM courses
             ORDER BY course_id DESC`
        );

        res.json(courses);
    } catch (error) {
        console.error("Fetch courses error:", error.message);
        res.status(500).json({
            message: "Unable to load courses"
        });
    }
});

// Register a course
app.post("/api/courses", async (req, res) => {
    const courseName = String(req.body.course_name || "").trim();
    const department = String(req.body.department || "").trim();
    const credits = Number(req.body.credits);
    const semester = Number(req.body.semester);

    if (
        !courseName ||
        courseName.length > 150 ||
        !department ||
        department.length > 100 ||
        !Number.isInteger(credits) ||
        credits < 1 ||
        credits > 30 ||
        !Number.isInteger(semester) ||
        semester < 1 ||
        semester > 8
    ) {
        return res.status(400).json({
            message: "Please enter valid course details."
        });
    }

    try {
        const [result] = await pool.execute(
            `INSERT INTO courses
             (course_name, credits, department, semester)
             VALUES (?, ?, ?, ?)`,
            [courseName, credits, department, semester]
        );

        res.status(201).json({
            message: "Course registered successfully",
            course_id: result.insertId
        });
    } catch (error) {
        console.error("Register course error:", error.message);
        res.status(500).json({
            message: "Unable to register course"
        });
    }
});

// Delete a course
app.delete("/api/courses/:id", async (req, res) => {
    const courseId = Number(req.params.id);

    if (!Number.isSafeInteger(courseId) || courseId < 1) {
        return res.status(400).json({
            message: "Invalid course ID"
        });
    }

    try {
        const [result] = await pool.execute(
            "DELETE FROM courses WHERE course_id = ?",
            [courseId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Course not found"
            });
        }

        res.json({
            message: "Course removed successfully"
        });
    } catch (error) {
        console.error("Delete course error:", error.message);
        res.status(500).json({
            message: "Unable to remove course"
        });
    }
});

app.get("/api/students", async (req, res) => {
    try {
        const [students] = await pool.query(`
            SELECT student_id, student_name, roll_number,
                   department, semester, email
            FROM students
            ORDER BY student_id ASC
        `);

        const [summary] = await pool.query(`
            SELECT
                COUNT(*) AS totalStudents,
                COUNT(DISTINCT department) AS totalDepartments,
                COUNT(DISTINCT semester) AS activeSemesters
            FROM students
        `);

        res.json({
            students,
            summary: summary[0]
        });
    } catch (error) {
        console.error("Fetch students error:", error.message);
        res.status(500).json({
            message: "Unable to load student records"
        });
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});